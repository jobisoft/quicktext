	<em:creator>Emil Hesslow</em:creator>
    <em:contributor>R Kent James</em:contributor>
    <em:contributor>John Bieling</em:contributor>
    <em:contributor>Philippe Lieser</em:contributor>
    <em:translator>Óvári (hu)</em:translator>
    <em:translator>Alexey Sinitsyn (ru)</em:translator>
pref("extensions.quicktext.defaultImport", "");
pref("extensions.quicktext.menuCollapse", true);
pref("extensions.quicktext.toolbar", true);
pref("extensions.quicktext.popup", false);
pref("extensions.quicktext.keywordKey", 9);
pref("extensions.quicktext.shortcutModifier", "alt");
pref("extensions.quicktext.shortcutTypeAdv", false);
